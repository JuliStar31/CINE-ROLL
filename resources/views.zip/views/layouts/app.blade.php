<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movierate - Laravel UI</title>
    <script src="https://tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-gray-100 font-sans">

    <!-- Navbar -->
    <nav class="bg-gray-800 border-b border-gray-700 px-6 py-4 flex justify-between items-center">
        <div class="text-xl font-bold text-indigo-500 tracking-wider">MOVIERATE</div>
        <div class="flex items-center gap-4">
            <span class="text-sm bg-indigo-600/20 text-indigo-400 px-3 py-1 rounded-full border border-indigo-500/30">
                Mode UI Demo
            </span>
        </div>
    </nav>

    <!-- Wrapper Konten -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        @yield('content')
    </div>

</body>
</html>
