@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div class="flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-bold">Katalog Film Modern</h2>
            <p class="text-gray-400 text-sm">Pilih film favoritmu dan lakukan checkout pesanan gambar.</p>
        </div>
        <a href="#" class="bg-gray-800 hover:bg-gray-700 border border-gray-700 px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
            🛒 Keranjang Pesanan <span class="bg-indigo-600 text-xs px-2 py-0.5 rounded-full">2</span>
        </a>
    </div>

    <!-- Grid Katalog Film -->
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
        
        <!-- Card 1 -->
        <div class="bg-gray-800 border border-gray-700 rounded-xl overflow-hidden shadow-lg group hover:border-indigo-500 transition duration-300">
            <div class="aspect-[2/3] bg-gray-700 relative flex items-center justify-center text-gray-400 font-semibold group-hover:scale-105 transition duration-300">
                <span>🎬 Cover Film 1</span>
                <div class="absolute top-2 right-2 bg-gray-900/80 backdrop-blur-md text-amber-400 px-2 py-0.5 rounded-md text-xs font-bold flex items-center gap-1">
                    ⭐ 4.8
                </div>
            </div>
            <div class="p-4 space-y-3">
                <div>
                    <h3 class="font-semibold text-white truncate text-sm">Interstellar</h3>
                    <p class="text-xs text-gray-400 line-clamp-1">Perjalanan fiksi ilmiah luar angkasa.</p>
                </div>
                <button onclick="triggerCheckout('Interstellar')" class="w-full bg-gray-700 hover:bg-indigo-600 text-white text-xs font-semibold py-2 rounded-lg transition duration-200">
                    + Checkout Pesanan
                </button>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="bg-gray-800 border border-gray-700 rounded-xl overflow-hidden shadow-lg group hover:border-indigo-500 transition duration-300">
            <div class="aspect-[2/3] bg-gray-700 relative flex items-center justify-center text-gray-400 font-semibold group-hover:scale-105 transition duration-300">
                <span>🎬 Cover Film 2</span>
                <div class="absolute top-2 right-2 bg-gray-900/80 backdrop-blur-md text-amber-400 px-2 py-0.5 rounded-md text-xs font-bold flex items-center gap-1">
                    ⭐ 4.5
                </div>
            </div>
            <div class="p-4 space-y-3">
                <div>
                    <h3 class="font-semibold text-white truncate text-sm">Inception</h3>
                    <p class="text-xs text-gray-400 line-clamp-1">Pencurian data di dalam alam mimpi.</p>
                </div>
                <button onclick="triggerCheckout('Inception')" class="w-full bg-gray-700 hover:bg-indigo-600 text-white text-xs font-semibold py-2 rounded-lg transition duration-200">
                    + Checkout Pesanan
                </button>
            </div>
        </div>

    </div>
</div>

<!-- Elemen Toast Notification -->
<div id="toastNotification" class="hidden fixed bottom-5 right-5 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg font-medium z-50">
    Cover film berhasil dimasukkan ke daftar pesanan!
</div>

<script>
    function triggerCheckout(movieTitle) {
        const toast = document.getElementById('toastNotification');
        toast.innerText = `🎉 Berhasil memesan gambar cover: ${movieTitle}`;
        toast.classList.remove('hidden');
        
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 3000);
    }
</script>
@endsection
