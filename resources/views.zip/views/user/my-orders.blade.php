@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <!-- Header Halaman -->
    <div>
        <h2 class="text-2xl font-bold">Koleksi Film Saya (Checked Out)</h2>
        <p class="text-gray-400 text-sm">Daftar cover film estetik yang sudah berhasil Anda pesan ke dalam akun.</p>
    </div>

    <!-- Grid List Pesanan -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        <!-- Item Pesanan 1 (Looping Data) -->
        <div class="bg-gray-800 border border-gray-700 p-4 rounded-xl flex gap-4 hover:border-indigo-500/50 transition duration-200">
            <!-- Cover Miniatur -->
            <div class="w-24 h-36 bg-gray-700 rounded-lg flex-shrink-0 flex items-center justify-center text-xs text-gray-500 font-medium overflow-hidden border border-gray-600">
                <span>[ Cover Film ]</span>
            </div>
            
            <!-- Detail Informasi -->
            <div class="flex flex-col justify-between py-1 flex-grow">
                <div>
                    <div class="flex items-center justify-between">
                        <h3 class="font-bold text-white text-base">Interstellar</h3>
                        <span class="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-medium">Berhasil</span>
                    </div>
                    <p class="text-xs text-gray-400 mt-1 line-clamp-2">Perjalanan luar angkasa melintasi lubang cacing demi menyelamatkan umat manusia.</p>
                </div>
                
                <div class="flex justify-between items-center pt-2 border-t border-gray-700/50 text-xs">
                    <span class="text-gray-500">Dipesan: 06 Ags 2026</span>
                    <button class="text-indigo-400 hover:text-indigo-300 font-semibold">
                        Lihat Detail
                    </button>
                </div>
            </div>
        </div>

        <!-- Item Pesanan 2 -->
        <div class="bg-gray-800 border border-gray-700 p-4 rounded-xl flex gap-4 hover:border-indigo-500/50 transition duration-200">
            <div class="w-24 h-36 bg-gray-700 rounded-lg flex-shrink-0 flex items-center justify-center text-xs text-gray-500 font-medium overflow-hidden border border-gray-600">
                <span>[ Cover Film ]</span>
            </div>
            
            <div class="flex flex-col justify-between py-1 flex-grow">
                <div>
                    <div class="flex items-center justify-between">
                        <h3 class="font-bold text-white text-base">Inception</h3>
                        <span class="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-medium">Berhasil</span>
                    </div>
                    <p class="text-xs text-gray-400 mt-1 line-clamp-2">Misi menanamkan ide ke dalam alam bawah sadar target melalui dunia mimpi.</p>
                </div>
                
                <div class="flex justify-between items-center pt-2 border-t border-gray-700/50 text-xs">
                    <span class="text-gray-500">Dipesan: 04 Ags 2026</span>
                    <button class="text-indigo-400 hover:text-indigo-300 font-semibold">
                        Lihat Detail
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection
