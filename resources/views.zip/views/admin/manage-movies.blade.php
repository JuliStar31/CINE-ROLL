@extends('layouts.app')

@section('content')
<div class="space-y-8">
    <div class="flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-bold">Kelola Profil & Cover Film</h2>
            <p class="text-gray-400 text-sm">Halaman khusus Admin untuk manajemen konten visual film.</p>
        </div>
        <!-- Tombol untuk memicu Jendela Pop-up JS -->
        <button onclick="toggleModal(true)" class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition shadow-lg shadow-indigo-600/20 text-sm">
            + Tambah Film Baru
        </button>
    </div>

    <!-- JENDELA POP-UP (MODAL) FORM - TERSEMBUNYI SECARA DEFAULT (hidden) -->
    <div id="movieModal" class="hidden fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 w-full max-w-2xl relative shadow-2xl">
            <h3 class="text-xl font-semibold mb-4 text-indigo-400">Form Film (Admin)</h3>
            
            <form action="#" method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label class="block text-sm text-gray-400 mb-1">Judul Film</label>
                    <input type="text" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500">
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1">Sinopsis / Deskripsi Profil</label>
                    <textarea rows="3" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"></textarea>
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1">Upload Gambar Cover Only</label>
                    <div class="border-2 border-dashed border-gray-600 rounded-lg p-4 text-center hover:border-indigo-500 transition cursor-pointer">
                        <p class="text-xs text-gray-400">Klik untuk pilih gambar (JPG/PNG)</p>
                        <input type="file" class="hidden">
                    </div>
                </div>
                
                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" onclick="toggleModal(false)" class="bg-gray-700 hover:bg-gray-600 text-gray-300 px-4 py-2 rounded-lg text-sm">Batal</button>
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium">Simpan Konten</button>
                </div>
            </form>
        </div>
    </div>

    <!-- TABEL UTAMA DAFTAR FILM (READ-ONLY RATING UNTUK ADMIN) -->
    <div class="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <!-- (Gunakan kode tabel dari jawaban pertama di sini) -->
    </div>
</div>

<!-- SCRIPT JAVASCRIPT VANILLA UNTUK MODAL -->
<script>
    function toggleModal(show) {
        const modal = document.getElementById('movieModal');
        if (show) {
            modal.classList.remove('hidden');
        } else {
            modal.classList.add('hidden');
        }
    }
</script>
@endsection
